#!/usr/bin/env python3
"""Validate effect sheets against effects_manifest.json. Usage: python tools/effects/validate_effects.py [assets/sprites/effects]"""
import json, sys, os
from PIL import Image
D = sys.argv[1] if len(sys.argv) > 1 else "assets/sprites/effects"
m = json.load(open(os.path.join(D, "effects_manifest.json")))["effects"]; fails = []
for e in m:
    p = os.path.join(D, e["sheet"])
    if not os.path.exists(p): fails.append(f"missing {e['sheet']}"); continue
    sh = Image.open(p).convert("RGBA"); w, h, n = e["frame_width"], e["frame_height"], e["frames"]
    if sh.size != (w*n, h): fails.append(f"{e['name']}: size {sh.size} != {(w*n, h)}")
    if not (0 <= e["pivot"][0] < w and 0 <= e["pivot"][1] < h): fails.append(f"{e['name']}: pivot outside frame")
    alphas = set(sh.getchannel("A").getdata())
    if not alphas <= {0, 96, 176, 255}: fails.append(f"{e['name']}: unexpected alpha levels {sorted(alphas - {0,96,176,255})[:5]}")
    for i in range(n):
        a = sh.crop((i*w, 0, i*w+w, h)).getchannel("A")
        if not a.getbbox(): fails.append(f"{e['name']}: blank frame {i}")
        if e["name"] != "fx_lightning_bolt":   # bolt tiles horizontally by design
            if any(a.getpixel((x, y)) for x in range(w) for y in (0, h-1)) or any(a.getpixel((x, y)) for y in range(h) for x in (0, w-1)):
                fails.append(f"{e['name']}: frame {i} touches cell edge")
    print(f"ok  {e['name']:20s} {w}x{h} x{n} @{e['fps']}fps loop={e['loop']}")
for f in fails: print("FAIL", f)
print(f"{len(m)} effects, {len(fails)} failures"); sys.exit(1 if fails else 0)
