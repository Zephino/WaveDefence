import json, sys
from PIL import Image, ImageDraw
D="sheets"; m=json.load(open(f"{D}/effects_manifest.json"))["effects"]
S=int(sys.argv[1]) if len(sys.argv)>1 else 5; names=sys.argv[2].split(",") if len(sys.argv)>2 else None
rows=[e for e in m if not names or e["name"] in names]
W=max(e["frame_width"]*e["frames"] for e in rows)*S+260; H=sum(e["frame_height"]*S+18 for e in rows)+10
img=Image.new("RGBA",(W,H),(64,96,58,255)); d=ImageDraw.Draw(img); y=6
for e in rows:
    sh=Image.open(f"{D}/{e['sheet']}").convert("RGBA")
    big=sh.resize((sh.width*S,sh.height*S),Image.NEAREST)
    for i in range(e["frames"]):          # cell boxes
        d.rectangle([250+i*e["frame_width"]*S,y,250+(i+1)*e["frame_width"]*S-1,y+e["frame_height"]*S-1],outline=(84,120,76))
    img.alpha_composite(big,(250,y))
    d.text((6,y+4),e["name"],fill=(255,255,255)); d.text((6,y+18),f"{e['frame_width']}x{e['frame_height']} x{e['frames']} @{e['fps']}fps",fill=(220,230,220))
    d.text((6,y+32),", ".join(e["used_by"]),fill=(255,230,150))
    y+=e["frame_height"]*S+18
img.save(sys.argv[3] if len(sys.argv)>3 else "contact.png"); print(img.size)
