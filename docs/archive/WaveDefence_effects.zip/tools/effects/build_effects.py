#!/usr/bin/env python3
"""WaveDefence attack-effect sprite builder (Pillow only, deterministic).
Style: showcase look - bright cores, saturated glow, stepped alpha (0/96/176/255) for crisp pixel glow.
Every sheet is ONE row of equal frames, no padding. Directional projectiles face RIGHT (+x); rotate in game.
Usage: python build_effects.py <out_dir>"""
import json, math, os, random, sys
from PIL import Image, ImageDraw

K = 8
OUT = sys.argv[1] if len(sys.argv) > 1 else "fx_out"
PAL = [(255,255,255),(255,246,200),(255,226,90),(255,192,40),(255,140,30),(232,72,30),(150,32,22),
       (60,56,64),(108,102,110),(168,164,170),(214,212,216),
       (236,252,255),(160,236,255),(70,198,255),(30,122,222),(20,62,140),
       (226,255,160),(160,240,52),(92,192,40),(40,122,42),(20,70,30),(150,80,200),
       (40,42,52),(100,104,118),(182,186,196),(146,116,86),(204,178,140),(96,72,52)]
A_STEPS = (0, 96, 176, 255)

class FX:
    def __init__(s, w, h, solid=False):
        s.w, s.h, s.solid = w, h, solid
        s.im = Image.new("RGBA", (w*K, h*K), (0,0,0,0)); s.d = ImageDraw.Draw(s.im, "RGBA")
    def P(s, pts): return [(x*K, y*K) for x, y in pts]
    def ell(s, cx, cy, rx, ry, c):
        if rx > 0 and ry > 0: s.d.ellipse([(cx-rx)*K,(cy-ry)*K,(cx+rx)*K,(cy+ry)*K], fill=c)
    def circ(s, cx, cy, r, c): s.ell(cx, cy, r, r, c)
    def poly(s, pts, c): s.d.polygon(s.P(pts), fill=c)
    def line(s, pts, w, c): s.d.line(s.P(pts), fill=c, width=max(1, int(w*K)), joint="curve")
    def ring(s, cx, cy, r, w, c): s.d.ellipse([(cx-r)*K,(cy-r)*K,(cx+r)*K,(cy+r)*K], outline=c, width=max(1,int(w*K)))
    def glow(s, cx, cy, r, core, mid, halo):          # 3-layer round glow
        s.circ(cx, cy, r*1.7, (*halo, 255)); s.circ(cx, cy, r*1.3, (*mid, 255)); s.circ(cx, cy, r, (*core, 255))
    def flame(s, bx, by, ang, ln, wd, c):            # teardrop tongue from base toward angle
        dx, dy = math.cos(ang), math.sin(ang); px, py = -dy, dx
        tip = (bx+dx*ln, by+dy*ln)
        pts = [(bx+px*wd, by+py*wd), (bx+dx*ln*0.45+px*wd*0.75, by+dy*ln*0.45+py*wd*0.75), tip,
               (bx+dx*ln*0.45-px*wd*0.75, by+dy*ln*0.45-py*wd*0.75), (bx-px*wd, by-py*wd)]
        s.poly(pts, c); s.circ(bx, by, wd, c)
    def done(s, outline=None):
        sm = s.im.resize((s.w, s.h), Image.BOX); px = sm.load()
        out = Image.new("RGBA", (s.w, s.h), (0,0,0,0)); op = out.load()
        for y in range(s.h):
            for x in range(s.w):
                r,g,b,a = px[x,y]
                if a < (60 if s.solid else 34): continue
                a2 = 255 if s.solid else min(A_STEPS[1:], key=lambda v: abs(v-a))
                c = min(PAL, key=lambda p: (p[0]-r)**2+(p[1]-g)**2+(p[2]-b)**2)
                op[x,y] = (*c, a2)
        if outline:
            res = out.copy(); rp = res.load()
            for y in range(s.h):
                for x in range(s.w):
                    if op[x,y][3] == 0:
                        for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                            xx,yy = x+dx,y+dy
                            if 0<=xx<s.w and 0<=yy<s.h and op[xx,yy][3] == 255:
                                rp[x,y] = (*outline,255); break
            out = res
        return out

WHITE=(255,255,255); CREAM=(255,246,200); YEL=(255,226,90); GOLD=(255,192,40); ORG=(255,140,30); RED=(232,72,30); DRED=(150,32,22)
SMK0=(60,56,64); SMK1=(108,102,110); SMK2=(168,164,170)
ICE0=(236,252,255); ICE1=(160,236,255); ICE2=(70,198,255); ICE3=(30,122,222); ICE4=(20,62,140)
PO0=(226,255,160); PO1=(160,240,52); PO2=(92,192,40); PO3=(40,122,42); PO4=(20,70,30)
MET0=(40,42,52); MET1=(100,104,118); MET2=(182,186,196); DUST=(146,116,86); DUST2=(204,178,140); EARTH=(96,72,52)

def ease(p): return 1-(1-p)**2

# ------------------------------------------------------------------ projectiles (face right, solid bands)
def tracer(n=4):                                     # gunner / rapid / gatling bullet
    fr=[]
    for f in range(n):
        s=FX(16,16,True); L=[10,11,9,11][f]; x1=13.5; x0=x1-L
        s.line([(x0+1.5,8),(x1,8)],3.8,(*RED,255)); s.line([(x0,8),(x1-0.4,8)],2.6,(*ORG,255))
        s.line([(x0+3,8),(x1-0.5,8)],1.4,(*YEL,255)); s.line([(x1-4,8),(x1,8)],1.3,(*WHITE,255)); s.circ(x1-0.6,8,1.3,(*CREAM,255))
        fr.append(s.done())
    return fr

def flak_shell(n=4):                                 # anti-air
    fr=[]
    for f in range(n):
        s=FX(16,16,True); g=[1.0,1.15,0.95,1.1][f]
        s.line([(3.5,8),(8,8)],2.6*g,(*ORG,255)); s.line([(4.5,8),(8,8)],1.2,(*YEL,255))
        s.poly([(7,5.6),(11,6.2),(13.4,8),(11,9.8),(7,10.4)],(*MET2,255)); s.poly([(7,5.6),(11,6.2),(11.4,7.4),(7,7.6)],(*WHITE,255))
        s.line([(7.3,5.8),(7.3,10.2)],1.0,(*RED,255)); s.circ(13,8,0.9,(*YEL,255))
        fr.append(s.done(outline=MET0))
    return fr

def cannon_shell(n=4):
    fr=[]
    for f in range(n):
        s=FX(16,16,True)
        for i,(x,r,c) in enumerate([(3.8,1.4,RED),(5.8,2.0,ORG),(7.6,2.4,YEL)]):
            s.circ(x+(f%2)*0.4,8+[0,0.4,0,-0.4][f]*i*0.5,r,(*c,255))
        s.circ(10,8,3.5,(*MET0,255)); s.circ(10,8,2.9,(*MET1,255))
        a=f*math.pi/2; s.circ(10+math.cos(a-2.3)*1.3,8+math.sin(a-2.3)*1.3,1.2,(*MET2,255))
        fr.append(s.done(outline=(24,22,30)))
    return fr

def fireball(n=4):                                   # burn
    fr=[]; rnd=random.Random(7)
    for f in range(n):
        s=FX(24,24,True); hx=16.5
        for k,(dy,ln,wd) in enumerate([(-2.6,9,2.4),(2.4,10,2.6),(0,13,3.4)]):
            wob=[0,1.2,-0.6,0.8][(f+k)%4]
            s.flame(hx-1,12+dy*0.6,math.pi+dy*0.06,ln+wob,wd,(*RED,255))
        s.flame(hx-1,12,math.pi,10+[0,1,0,-1][f],2.5,(*ORG,255))
        s.flame(hx,12,math.pi,6+[0,0.6,0,0.6][f],1.6,(*YEL,255))
        s.circ(hx,12,5.6,(*RED,255)); s.circ(hx,12,4.5,(*ORG,255)); s.circ(hx+0.3,12,3.2,(*YEL,255)); s.circ(hx+0.8,11.4,1.7,(*CREAM,255))
        for e in range(3):
            ex=max(2.6,hx-9.5-e*2.4-((f+e)%4)*0.5); ey=12+rnd.uniform(-4,4); s.circ(ex,ey,0.8,(*YEL,255))
        fr.append(s.done(outline=DRED))
    return fr

def _frost_sparkles(f):                              # loose trail sparkles, no outline, clear of the body
    t=FX(24,24,True)
    pts=[[(3.0,9.8,1.1),(2.8,14.4,0)],[(2.6,13.8,1.1),(3.8,9.6,0)],[(3.2,14.8,1.0),(2.6,10.2,0)],[(2.8,10.4,0),(3.2,14.0,1.1)]][f]
    for x,y,r in pts:
        if r: t.line([(x-r,y),(x+r,y)],0.8,(*WHITE,255)); t.line([(x,y-r),(x,y+r)],0.8,(*WHITE,255))
        else: t.circ(x,y,0.5,(*ICE1,255))
    return t.done()

def ice_shard(n=4):                                  # freeze: spinning 6-arm snowflake (15 deg/frame = seamless loop)
    fr=[]
    for f in range(n):
        s=FX(24,24,True); cx,cy=14,12; rot=f*math.radians(15)
        for k in range(6):
            a=rot+k*math.pi/3; ex,ey=cx+math.cos(a)*7.2,cy+math.sin(a)*7.2
            s.line([(cx,cy),(ex,ey)],1.9,(*ICE1,255))
            bx,by=cx+math.cos(a)*4.2,cy+math.sin(a)*4.2
            for sgn in (-1,1):
                b=a+sgn*0.85; s.line([(bx,by),(bx+math.cos(b)*2.4,by+math.sin(b)*2.4)],1.2,(*ICE1,255))
            s.circ(ex,ey,1.0,(*ICE0,255))
        s.circ(cx,cy,2.6,(*ICE2,255)); s.circ(cx,cy,1.4,(*WHITE,255))
        img=s.done(outline=ICE4); img.alpha_composite(_frost_sparkles(f)); fr.append(img)
    return fr

def poison_glob(n=4):
    fr=[]
    for f in range(n):
        s=FX(24,24,True); sx=[1.0,1.1,0.95,1.05][f]; sy=1/sx; hx=15
        for i,(dx,dy,r) in enumerate([(-6.4,1.6,1.4),(-9.2,-1.2,1.0),(-11.8,1.0,0.8)]):
            s.circ(hx+dx-(f%2)*0.6,12+dy,r,(*PO2,255)); s.circ(hx+dx-(f%2)*0.6-0.3,12+dy-0.3,r*0.45,(*PO0,255))
        s.ell(hx,12,5.0*sx,4.4*sy,(*PO3,255)); s.ell(hx-0.3,11.6,4.3*sx,3.7*sy,(*PO2,255)); s.ell(hx-1,11,3.0*sx,2.4*sy,(*PO1,255))
        s.circ(hx-1.8,10,1.2,(*PO0,255)); s.circ(hx+2,13.4,0.9,(*PO4,255)); s.circ(hx+1,10.6,0.7,(*PO4,255))
        fr.append(s.done(outline=PO4))
    return fr

def lightning_segment(n=4, w=64, h=16):              # tiles horizontally; repeat/stretch along chain
    fr=[]
    for f in range(n):
        rnd=random.Random(100+f); s=FX(w,h,True); cy=h/2
        pts=[(0,cy)]
        for i in range(1,8): pts.append((i*w/8, cy+rnd.uniform(-4.2,4.2)))
        pts.append((w,cy))
        s.line(pts,3.6,(*GOLD,255)); s.line(pts,2.3,(*YEL,255)); s.line(pts,1.0,(*WHITE,255))
        for _ in range(2):
            i=rnd.randint(1,6); bx,by=pts[i]; ex=bx+rnd.uniform(4,8); ey=by+rnd.choice([-1,1])*rnd.uniform(3,5)
            ey=max(1.5,min(h-1.5,ey)); s.line([(bx,by),(ex,ey)],1.5,(*GOLD,255)); s.line([(bx,by),(ex,ey)],0.6,(*YEL,255))
        fr.append(s.done())
    return fr

# ------------------------------------------------------------------ one-shots
def muzzle_flash(n=4):                               # pivot at left-middle (x=2,y=10)
    fr=[]
    for f in range(n):
        oy=10
        if f<3:
            s=FX(20,20,True); sc=[0.72,0.92,0.58][f]
            s.flame(5,oy,0,12.5*sc,3.2*sc,(*ORG,255))
            for a in (-0.8,0.8): s.flame(5.5,oy,a,7*sc,1.6*sc,(*ORG,255))
            s.flame(5,oy,0,10*sc,2.3*sc,(*YEL,255))
            s.flame(5,oy,0,5.5*sc,1.3*sc,(*WHITE,255))
        else:
            s=FX(20,20); s.circ(7,oy-1,3.2,(*SMK2,176)); s.circ(10,oy+0.6,2.2,(*SMK2,96))
        fr.append(s.done())
    return fr

def hit_spark(n=5):
    fr=[]; rnd=random.Random(3); rays=[rnd.uniform(0,2*math.pi) for _ in range(7)]
    for f in range(n):
        s=FX(24,24,True); c=12; p=f/(n-1)
        if f==0: s.glow(c,c,3.0,WHITE,YEL,ORG)
        else:
            for i,a in enumerate(rays):
                r0=2+p*6; r1=r0+[5,4,3,2][f-1]*(0.8+0.3*(i%2))
                col=(*YEL,255) if f<3 else (*ORG,255)
                s.line([(c+math.cos(a)*r0,c+math.sin(a)*r0),(c+math.cos(a)*r1,c+math.sin(a)*r1)],[1.6,1.3,1.0,0.9][f-1],col)
            if f<3: s.circ(c,c,[2.6,1.6][f-1],(*CREAM,255))
        fr.append(s.done())
    return fr

def explosion(n=7, size=48):                         # cannon splash; scale to splash radius in game
    fr=[]; rnd=random.Random(11); c=size/2
    puffs=[(i*2*math.pi/8+rnd.uniform(-0.3,0.3), rnd.uniform(0.55,0.95), rnd.uniform(0.85,1.15)) for i in range(8)]
    R_=[0,9,12.5,14.5,14,14.5,13]
    for f in range(n):
        if f==0:
            s=FX(size,size,True); s.glow(c,c,6,WHITE,YEL,ORG); fr.append(s.done()); continue
        R=R_[f]; s=FX(size,size, f<=4)
        rise=max(0,f-3)*1.6
        if f>=3:                                      # smoke behind fire
            col=SMK0 if f<=4 else (SMK1 if f==5 else SMK2); al=255 if f<=4 else (176 if f==5 else 96)
            for a,d,sz in puffs: s.circ(c+math.cos(a)*R*d*0.72,c+math.sin(a)*R*d*0.72-rise,(2.4+R*0.3)*sz,(*col,al))
        fire=[0,1.0,1.0,0.8,0.45,0.2,0][f]
        if fire>0:
            for a,d,sz in puffs: s.circ(c+math.cos(a)*R*d*0.55,c+math.sin(a)*R*d*0.55,(2.2+R*0.28)*sz*fire,(*RED,255))
            s.circ(c,c,R*0.72*fire,(*ORG,255)); s.circ(c,c,R*0.48*fire,(*YEL,255)); s.circ(c-1,c-1,R*0.26*fire,(*CREAM,255))
        if f in (1,2): s.ring(c,c,[15,19.5][f-1],1.1,(*CREAM,255))
        if 2<=f<=4:
            for i in range(6):
                a=i*math.pi/3+0.4; r=[0,0,16,18.5,20.5][f]; s.circ(c+math.cos(a)*r,c+math.sin(a)*r,0.9,(*YEL,255))
        fr.append(s.done())
    return fr

def fire_burst(n=6, size=32):
    fr=[]; c=size/2
    for f in range(n):
        p=f/(n-1)
        if f==0:
            s=FX(size,size,True); s.glow(c,c+3,4,WHITE,YEL,ORG)
        elif f<=3:
            s=FX(size,size,True); k=[0.8,1.15,0.95][f-1]; by=c+5
            for i in range(7):
                a=-math.pi/2+(i-3)*0.5; s.flame(c,by,a,(8+(i%2)*3.5)*k,2.6*k,(*RED,255))
            for i in range(5):
                a=-math.pi/2+(i-2)*0.55; s.flame(c,by,a,(6+(i%2)*2.5)*k,1.9*k,(*ORG,255))
            s.flame(c,by,-math.pi/2,7*k,1.6*k,(*YEL,255)); s.circ(c,by,2*k,(*CREAM,255))
        else:
            s=FX(size,size); q=f-4
            for (dx,dy) in [(-6,-6),(5,-8),(-2,-11),(7,-3),(-8,0)]:
                s.circ(c+dx,c+dy-q*3,1.0,((*YEL,255) if q==0 else (*ORG,255)))
            s.circ(c,c-3-q*4,3.4+q,(*SMK1,176 if q==0 else 96))
        fr.append(s.done(outline=DRED if f in (1,2,3) else None))
    return fr

def frost_burst(n=6, size=32):
    fr=[]; c=size/2
    for f in range(n):
        p=f/(n-1); s=FX(size,size, f<5)
        if f==0: s.glow(c,c,3.4,WHITE,ICE1,ICE2)
        else:
            R=3+ease(p)*9
            if f<=3: s.ring(c,c,R+1,1.0,(*ICE1,255))
            if f<=4:
                for i in range(6):
                    a=i*math.pi/3+0.26; tx,ty=c+math.cos(a)*min(R+4,12.5),c+math.sin(a)*min(R+4,12.5); bx,by=c+math.cos(a)*R*0.5,c+math.sin(a)*R*0.5
                    px,py=-math.sin(a)*1.6,math.cos(a)*1.6
                    s.poly([(bx+px,by+py),(tx,ty),(bx-px,by-py)],(*ICE3,255)); s.poly([(bx+px*0.5,by+py*0.5),(tx,ty),(bx,by)],(*ICE1,255))
            if f<=2: s.circ(c,c,[3,2][f-1],(*ICE0,255))
            for i in range(4):
                a=i*math.pi/2+f*0.5; r=min(R+2+(i%2)*3,12); x,y=c+math.cos(a)*r,c+math.sin(a)*r
                s.line([(x-1.4,y),(x+1.4,y)],0.8,(*WHITE,255)); s.line([(x,y-1.4),(x,y+1.4)],0.8,(*WHITE,255))
        fr.append(s.done(outline=ICE4 if 1<=f<=4 else None))
    return fr

def poison_cloud(n=6, size=40):
    fr=[]; c=size/2; rnd=random.Random(21)
    puffs=[(i*2*math.pi/7+rnd.uniform(-0.3,0.3), rnd.uniform(0.35,0.95), rnd.uniform(0.85,1.15)) for i in range(7)]
    for f in range(n):
        p=f/(n-1)
        if f==0:
            s=FX(size,size,True)
            for i in range(8):
                a=i*math.pi/4+0.2; s.circ(c+math.cos(a)*5.5,c+math.sin(a)*5.5,1.5,(*PO1,255))
            s.ell(c,c,5,4.4,(*PO2,255)); s.ell(c-1,c-1,3.4,2.8,(*PO1,255)); s.circ(c-2,c-2,1,(*PO0,255))
            fr.append(s.done(outline=PO4)); continue
        solid=f<=2; s=FX(size,size,solid); R=6+ease(p)*7; al=255 if solid else (176 if f<=4 else 96)
        for a,d,sz in puffs: s.circ(c+math.cos(a)*R*d*0.8,c+math.sin(a)*R*d*0.8,(3.2+R*0.3)*sz+0.9,(*PO4,al))
        for a,d,sz in puffs: s.circ(c+math.cos(a)*R*d*0.8,c+math.sin(a)*R*d*0.8,(3.2+R*0.3)*sz,(*PO2,al))
        for a,d,sz in puffs[:4]: s.circ(c+math.cos(a)*R*d*0.6-1,c+math.sin(a)*R*d*0.6-1.4,(1.8+R*0.2)*sz,(*PO1,al))
        for i in range(3):
            a=i*2.1+f; r=R*0.5; x,y=c+math.cos(a)*r,c+math.sin(a)*r-f
            if (f+i)%2: s.ring(x,y,1.3,0.7,(*PO0,al))
            else: s.circ(x,y,1.1,(*PO0,al))
        fr.append(s.done())
    return fr

def lightning_spark(n=5, size=24):
    fr=[]; c=size/2
    for f in range(n):
        s=FX(size,size, f<4); rnd=random.Random(50+f)
        if f==0: s.glow(c,c,3.2,WHITE,YEL,GOLD)
        else:
            L=[6,9,10,7][f-1]
            for i in range(5):
                a=i*2*math.pi/5+f*0.7; pts=[(c,c)]
                for k in range(1,4):
                    r=L*k/3; j=rnd.uniform(-0.45,0.45); pts.append((c+math.cos(a+j)*r,c+math.sin(a+j)*r))
                s.line(pts,2.2,(*GOLD,255 if f<4 else 96)); s.line(pts,0.9,(*CREAM,255 if f<4 else 176))
            if f<3: s.circ(c,c,[2.6,1.8][f-1],(*WHITE,255))
        fr.append(s.done())
    return fr

def flak_burst(n=6, size=32):
    fr=[]; c=size/2; rnd=random.Random(31)
    puffs=[(rnd.uniform(0,2*math.pi), rnd.uniform(0.2,1.0), rnd.uniform(0.8,1.2)) for _ in range(6)]
    shards=[rnd.uniform(0,2*math.pi) for _ in range(8)]
    for f in range(n):
        p=f/(n-1); s=FX(size,size, f<=3)
        if f==0: s.glow(c,c,3.2,WHITE,YEL,ORG)
        else:
            R=3+ease(p)*6.5; al=255 if f<=3 else (176 if f==4 else 96)
            for a,d,sz in puffs: s.circ(c+math.cos(a)*R*d,c+math.sin(a)*R*d,(2.4+R*0.35)*sz,(*SMK0,al))
            for a,d,sz in puffs[:3]: s.circ(c+math.cos(a)*R*d*0.6-1,c+math.sin(a)*R*d*0.6-1,(1.5+R*0.2)*sz,(*SMK1,al))
            if f<=2: s.circ(c,c,[4,2.4][f-1],(*ORG,255)); s.circ(c,c,[2.4,1.2][f-1],(*YEL,255))
            if f<=4:
                for a in shards:
                    r=min(R+3+f*1.4,14.2); s.line([(c+math.cos(a)*(r-1.6),c+math.sin(a)*(r-1.6)),(c+math.cos(a)*r,c+math.sin(a)*r)],0.9,(*YEL,255))
        fr.append(s.done())
    return fr

def spike_burst(n=5, size=32):                       # melee ground strike (3/4 view, spikes point up)
    fr=[]; c=size/2
    spikes=[(-7,3,0.8),(-2.5,1,1.15),(2.5,2.4,1.0),(7,4,0.75),(0,5.5,0.7)]
    for f in range(n):
        s=FX(size,size, f<4); gy=c+7
        k=[0.3,1.0,0.9,0.4,0][f]
        s.ell(c,gy,10.5,3.4,(*EARTH,255 if f<4 else 96))
        if f<4:
            for dx in (-6,0,5): s.line([(c+dx,gy),(c+dx*1.4+1,gy+2.2)],0.8,(*MET0,255))
        if f>=1:
            dr=2.5+f; al=255 if f<4 else 96
            for dx in (-1,1): s.ell(c+dx*(5+f*1.2),gy-1,dr*0.65,dr*0.42,(*DUST2,al))
        for dx,dy,h in spikes:
            if k<=0: continue
            hh=13*h*k; bx=c+dx; by=gy+dy*0.3-1
            s.poly([(bx-2.3,by),(bx,by-hh),(bx+2.3,by)],(*MET1,255)); s.poly([(bx-2.3,by),(bx,by-hh),(bx-0.2,by)],(*MET2,255))
            s.circ(bx,by-hh+0.7,0.6,(*WHITE,255))
        fr.append(s.done(outline=(30,26,30) if f<4 else None))
    return fr

EFFECTS = {
  # name: (fn, frame_w, frame_h, fps, loop, pivot, used_by, note)
  "fx_tracer":         (tracer,           16,16, 16, True,  [8,8],  ["gunner","rapid","gatling"], "projectile, faces right"),
  "fx_flak_shell":     (flak_shell,       16,16, 16, True,  [8,8],  ["antiair"], "projectile, faces right"),
  "fx_cannon_shell":   (cannon_shell,     16,16, 12, True,  [10,8], ["cannon"], "projectile, faces right"),
  "fx_fireball":       (fireball,         24,24, 12, True,  [16,12],["burn"], "projectile, faces right"),
  "fx_ice_shard":      (ice_shard,        24,24, 10, True,  [14,12],["freeze"], "spinning snowflake projectile; sparkle trail on the left, so rotate to travel direction"),
  "fx_poison_glob":    (poison_glob,      24,24, 10, True,  [15,12],["poison"], "projectile, faces right"),
  "fx_lightning_bolt": (lightning_segment,64,16, 20, True,  [0,8],  ["lightning"], "tiling beam segment; repeat along chain"),
  "fx_muzzle_flash":   (muzzle_flash,     20,20, 24, False, [5,10], ["gunner","rapid","gatling","cannon","antiair"], "one-shot at muzzle, faces right"),
  "fx_hit_spark":      (hit_spark,        24,24, 20, False, [12,12],["gunner","rapid","gatling"], "impact"),
  "fx_explosion":      (explosion,        48,48, 16, False, [24,24],["cannon"], "splash impact; scale to splash radius"),
  "fx_fire_burst":     (fire_burst,       32,32, 14, False, [16,16],["burn"], "impact"),
  "fx_frost_burst":    (frost_burst,      32,32, 14, False, [16,16],["freeze"], "impact"),
  "fx_poison_cloud":   (poison_cloud,     40,40, 10, False, [20,20],["poison"], "splash impact"),
  "fx_lightning_spark":(lightning_spark,  24,24, 20, False, [12,12],["lightning"], "impact at each chain hop"),
  "fx_flak_burst":     (flak_burst,       32,32, 16, False, [16,16],["antiair"], "air-burst impact"),
  "fx_spike_burst":    (spike_burst,      32,32, 14, False, [16,22],["spike"], "melee strike at enemy"),
}

def build(out):
    os.makedirs(out, exist_ok=True); manifest=[]; frames_all={}
    for name,(fn,w,h,fps,loop,pivot,used,note) in EFFECTS.items():
        frames=fn(); n=len(frames)
        sheet=Image.new("RGBA",(w*n,h),(0,0,0,0))
        for i,fimg in enumerate(frames): sheet.alpha_composite(fimg,(i*w,0))
        sheet.save(os.path.join(out,f"{name}_sheet.png"), optimize=True)
        manifest.append({"name":name,"sheet":f"{name}_sheet.png","frame_width":w,"frame_height":h,"frames":n,
                         "columns":n,"rows":1,"fps":fps,"loop":loop,"pivot":pivot,"used_by":used,"note":note,
                         "blend":"add-friendly (stepped alpha 0/96/176/255)"})
        frames_all[name]=frames
    json.dump({"version":1,"style":"WaveDefence showcase: saturated glow, cartoon sci-fi","effects":manifest},
              open(os.path.join(out,"effects_manifest.json"),"w"),indent=2)
    return manifest, frames_all

if __name__=="__main__":
    m,_=build(OUT); print("built",len(m),"effect sheets ->",OUT)
