# WaveDefence Godot 4 helper: create SpriteFrames from exported atlas sheets.
# Use in a tower node with AnimatedSprite2D; does NOT change game mechanics.
class_name WaveTowerSprites
extends RefCounted

const DIR: String = "res://assets/sprites/towers/"
const TOWERS: Array[String] = [
    "wall", "gunner", "rapid", "cannon", "burn", "freeze",
    "poison", "lightning", "spike", "antiair", "gatling", "vortex", "command"
]

static func make_frames(id: String, use_large_vortex: bool = false) -> SpriteFrames:
    if not (id in TOWERS):
        push_error("Unknown tower sprite: " + id)
        return SpriteFrames.new()
    var big: bool = id == "vortex" and use_large_vortex
    var frame_size: int = 120 if big else 40
    var path: String = DIR + ("tower_vortex_3x3_sheet.png" if big else "tower_" + id + "_sheet.png")
    var atlas: Texture2D = load(path)
    var result := SpriteFrames.new()
    if result.has_animation("default"):
        result.remove_animation("default")
    if atlas == null:
        push_error("Missing tower sprite sheet: " + path)
        return result
    for anim in ["idle", "action"]:
        var row: int = 0 if anim == "idle" else 1
        result.add_animation(anim)
        result.set_animation_speed(anim, 6.0 if anim == "idle" else 10.0)
        result.set_animation_loop(anim, anim == "idle")
        for col in range(4):
            var region := AtlasTexture.new()
            region.atlas = atlas
            region.region = Rect2(col * frame_size, row * frame_size, frame_size, frame_size)
            result.add_frame(anim, region)
    return result

# Neighbors are walls, including cells that also hold a tower.
# bitmask: north=1, east=2, south=4, west=8.
static func wall_tile(neighbor_mask: int) -> AtlasTexture:
    var atlas: Texture2D = load(DIR + "tower_wall_autotile_16.png")
    var tex := AtlasTexture.new()
    tex.atlas = atlas
    var i: int = neighbor_mask & 15
    tex.region = Rect2((i % 4) * 40, int(i / 4) * 40, 40, 40)
    return tex
