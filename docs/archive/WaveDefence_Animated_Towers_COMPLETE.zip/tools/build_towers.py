#!/usr/bin/env python3
"""Deterministic Pillow builder for WaveDefence animated tower sprite pack.
Reference art (already approved in chat) is used to derive base 40px assets;
Pillow generates 4-frame idle and 4-frame action/placement loops and VFX.
Run from ZIP root: python tools/build_towers.py
"""
from PIL import Image, ImageDraw, ImageEnhance
import math, json, shutil, zipfile, datetime, hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
D=ROOT/'assets'/'sprites'/'towers'; D.mkdir(parents=True,exist_ok=True)
SRC=ROOT/'tools'/'base_art'; SRC.mkdir(parents=True,exist_ok=True)
REF=ROOT/'tools'/'references'; REF.mkdir(parents=True,exist_ok=True)
META=[]
C={"black":(29,31,43,255),"metal":(94,100,116,255),"metal2":(150,155,164,255),"silver":(223,225,218,255),"orange":(247,154,39,255),"gold":(255,214,65,255),"cream":(255,246,191,255),"ice":(68,213,255,255),"pale":(174,245,255,255),"green":(105,240,55,255),"lime":(199,255,81,255),"purple":(153,83,241,255),"pink":(239,162,255,255),"wood":(161,96,44,255),"stone":(187,184,179,255),"shadow":(73,74,88,255),"empty":(0,0,0,0)}

def blank(w=40,h=None): return Image.new('RGBA',(w,h or w),(0,0,0,0))
def oellipse(im,xy,fill,outline=None,width=1): ImageDraw.Draw(im).ellipse(tuple(map(int,xy)),fill=fill,outline=outline,width=width)
def rect(im,xy,fill,outline=None,width=1): ImageDraw.Draw(im).rectangle(tuple(map(int,xy)),fill=fill,outline=outline,width=width)
def poly(im,pts,fill,outline=None): ImageDraw.Draw(im).polygon([(int(x),int(y)) for x,y in pts],fill=fill,outline=outline)
def line(im,pts,fill,width=1,joint='curve'): ImageDraw.Draw(im).line([(int(x),int(y)) for x,y in pts],fill=fill,width=width,joint=joint)
def circ(im,x,y,r,color,outline=None): oellipse(im,(x-r,y-r,x+r,y+r),color,outline)
def mul_alpha(im,alpha):
    out=im.copy(); a=out.getchannel('A').point(lambda x: int(x*alpha));out.putalpha(a);return out

def clean_source(path, size=34):
    im=Image.open(path).convert('RGBA')
    # remove low alpha hallucination pixels and trim to actual subject
    mask=im.getchannel('A').point(lambda a: 255 if a>38 else 0)
    bb=mask.getbbox()
    if not bb: raise ValueError('empty art '+str(path))
    im=im.crop(bb)
    # final body fits 34x34 max, preserving silhouette
    scale=min(size/im.width,size/im.height)
    n=(max(1,int(round(im.width*scale))),max(1,int(round(im.height*scale))))
    im=im.resize(n,Image.Resampling.LANCZOS)
    # quantize to reduced palette (RGB) and binary alpha for clean low-res pixel art
    rgb=Image.new('RGB',im.size,(95,94,97));rgb.paste(im,mask=im.getchannel('A'))
    rgb=ImageEnhance.Contrast(rgb).enhance(1.16)
    rgb=rgb.quantize(colors=28,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE).convert('RGB')
    alpha=im.getchannel('A').point(lambda a:255 if a>=106 else 0)
    rgb=rgb.convert('RGBA');rgb.putalpha(alpha)
    out=blank()
    x=(40-n[0])//2
    y=(40-n[1])//2
    out.alpha_composite(rgb,(x,y))
    return out

def to_png(im,path): im.save(path,optimize=True)

def rim(im, cx,cy, radius,frame,color,span=6,width=1):
    ang0=frame*25
    for z in range(span):
        ang=math.radians(ang0+z*4)
        x1=int(round(cx+math.cos(ang)*(radius-2)));y1=int(round(cy+math.sin(ang)*(radius-2)))
        x2=int(round(cx+math.cos(ang)*(radius+2)));y2=int(round(cy+math.sin(ang)*(radius+2)))
        line(im,[(x1,y1),(x2,y2)],color,width)

def sparkle(im,x,y,color,sz=2):
    line(im,[(x-sz,y),(x+sz,y)],color,1);line(im,[(x,y-sz),(x,y+sz)],color,1)

def zig(im,points,outer,inner=None):
    line(im,points,outer,3)
    if inner:line(im,points,inner,1)

def shifted(base,dx=0,dy=0):
    a=blank(base.width,base.height)
    a.paste(base,(int(dx),int(dy)),base)
    return a

def center_light(im,fx,fy,color,r=2):
    circ(im,fx,fy,r,color)
    if r>2: circ(im,fx,fy,r-2,C['cream'])

def overlay(name,k,f,im,fx=False):
    # Effects are separate transparent overlays, aligned to cell coordinates.
    # All attack endpoints are within the 40px cell.
    if name=='gunner':
        if fx:
            if f==0: center_light(im,31,17,C['gold'],2)
            if f==1:
                poly(im,[(30,17),(36,14),(33,17),(37,19),(30,18)],C['orange']);sparkle(im,34,17,C['cream'],2)
            if f==2:
                poly(im,[(29,17),(38,14),(34,17),(38,19),(29,19)],C['gold']);sparkle(im,35,17,C['cream'],3)
            if f==3: sparkle(im,32,18,C['gold'],1)
        else:
            if f%2==1: circ(im,9,17,1,C['gold'])
    elif name=='rapid':
        if fx:
            for yy in ([15],[20],[15,20],[20])[f]:
                poly(im,[(30,yy),(35,yy-2),(33,yy),(38,yy),(33,yy+1)],C['gold'])
                sparkle(im,36,yy,C['cream'],1)
        else: rim(im,23,20,4,f,C['orange'])
    elif name=='cannon':
        if fx:
            if f<3:
                r=[2,4,6][f]; oellipse(im,(24-r,11-r,24+r,11+r),C['orange'] if f==1 else C['metal2']); circ(im,24,11,1,C['cream'])
                for xx,yy in ((27,7),(19,8),(25,17)):
                    if 0<=xx<40 and 0<=yy<40: circ(im,xx,yy,1,C['silver'])
            else: sparkle(im,22,9,C['silver'],1)
        else:
            if f in (0,2): circ(im,23,11,1,C['orange'])
    elif name=='burn':
        if fx:
            poly(im,[(21,6),(17,13),(19,16),(25,16),(29,12),(25,8),(25,3)],C['orange'])
            poly(im,[(22,9),(20,13),(22,16),(25,15),(25,10)],C['gold'])
            for i in range(f+1):
                x=17+(i*7)%15; y=3+(f+i)%5
                circ(im,x,y,1,C['orange'] if i%2 else C['gold'])
        else: circ(im,20,8,1,C['orange'] if f%2 else C['gold'])
    elif name=='freeze':
        if fx:
            for i in range(f+1):
                xx=18+((-1)**i)*(i+1)*3; yy=8+(i%2)*3
                poly(im,[(xx,yy-3),(xx+2,yy),(xx,yy+4),(xx-2,yy)],C['ice'])
            sparkle(im,20,9,C['pale'],2)
        else: sparkle(im,18,9,C['pale'] if f%2 else C['ice'],1)
    elif name=='poison':
        if fx:
            for j in range(4):
                x=13+((j*7+f*2)%19);y=8+((f*5+j*7)%14)
                if j<=f: circ(im,x,y,max(1,3-j//2),C['lime'] if j%2 else C['green'])
        else:
            if f%2: circ(im,16,7,2,C['green'])
    elif name=='lightning':
        if fx:
            pts=[[(17,12),(12,7),(18,4),(23,8),(29,5)],[(17,14),(10,17),(17,21),(25,15),(31,20)],[(21,10),(29,11),(33,6),(35,12)],[(16,11),(10,7),(16,5)]]
            zig(im,pts[f],C['gold'],C['cream'])
            sparkle(im,20,9,C['gold'],2)
        else:
            for j in range(2): sparkle(im,17+j*7,11+(f+j)%3,C['gold'],1)
    elif name=='spike':
        if fx:
            s=[0,1,2,1][f]
            for xx,yy in ((13,18),(21,11),(27,20),(20,25)):
                poly(im,[(xx-2,yy+3),(xx,yy-5-s),(xx+3,yy+3)],C['silver'])
                line(im,[(xx,yy-5-s),(xx+2,yy+2)],C['cream'])
        else:
            if f%2: sparkle(im,20,12,C['silver'],1)
    elif name=='antiair':
        if fx:
            for j,(x,y) in enumerate([(19,8),(28,11)]):
                if f==1 or f==3 or (f==2 and j==0):
                    poly(im,[(x,y),(x-2,y-5),(x,y-3),(x+3,y-6),(x+2,y-1)],C['gold'])
                    sparkle(im,x,y-4,C['cream'])
        else:
            if f%2==1: circ(im,20,25,1,C['orange'])
    elif name=='gatling':
        if fx:
            for j,(x,y) in enumerate([(29,12),(33,16),(32,21),(27,24)]):
                if (j+f)%2==0:
                    poly(im,[(x,y),(37,min(y+1,35)),(x+1,y+2)],C['orange'])
                    sparkle(im,35,min(y,34),C['cream'])
        else: rim(im,27,18,5,f,C['gold'],8)
    elif name=='vortex':
        if fx:
            for j in range(5):
                a=math.radians(f*33+j*72)
                x=int(20+11*math.cos(a));y=int(20+10*math.sin(a))
                circ(im,x,y,2,C['purple'] if j%2 else C['pink'])
            sparkle(im,20,20,C['cream'],2)
        else:
            for j in range(3):
                a=math.radians(f*26+j*120)
                sparkle(im,int(20+6*math.cos(a)),int(20+6*math.sin(a)),C['pink'],1)
    elif name=='command':
        if fx:
            rim(im,20,11,7,f*2,C['green'],span=10)
            for j in range(f+1): sparkle(im,12+j*5,6+j%2,C['gold'],1)
        else:
            if f%2==1: circ(im,20,11,1,C['gold'])
    return im

def gatling_base():
    im=blank(); sh=C['black'];metal=C['metal'];edge=C['metal2'];gold=C['orange']
    oellipse(im,(4,24,35,37),sh)
    oellipse(im,(6,25,33,35),metal,sh)
    rect(im,(10,26,30,28),gold)
    oellipse(im,(12,11,29,28),metal,sh)
    poly(im,[(13,13),(17,7),(24,7),(28,14),(28,23),(15,26)],edge,sh)
    oellipse(im,(18,13,35,27),sh)
    for x,y in ((28,15),(32,17),(32,22),(28,24),(23,20)):
        circ(im,x,y,3,metal,sh)
        circ(im,x,y,1,C['orange'])
    rect(im,(10,28,27,29),C['orange'])
    return im

def vortex_base(sz=40):
    # 40px version; do not use on enlarged field directly
    im=blank()
    oellipse(im,(5,24,35,36),C['black'])
    oellipse(im,(8,25,32,34),C['metal2'])
    oellipse(im,(9,10,31,31),C['purple'],C['black'])
    oellipse(im,(13,14,27,27),C['black'])
    circ(im,20,20,4,C['pink'])
    for x,y in [(12,16),(28,18),(17,11)]:sparkle(im,x,y,C['cream'],1)
    return im

def command_base():
    im=blank()
    oellipse(im,(3,26,36,36),C['black'])
    oellipse(im,(5,25,34,34),C['metal2'],C['black'])
    rect(im,(9,18,30,29),C['metal'],C['black'])
    rect(im,(12,20,17,25),C['green'])
    rect(im,(20,19,27,26),C['orange'])
    rect(im,(17,10,21,21),C['metal2'],C['black'])
    oellipse(im,(10,7,30,16),C['metal2'],C['black'])
    oellipse(im,(13,8,27,14),C['green'])
    circ(im,20,11,2,C['cream'])
    rect(im,(8,27,32,29),C['orange'])
    return im

SOURCE_MAP={
'gunner':'sci_fi_orange_accented_gun_turret.png',
'rapid':'rapid_twin_barrel_defense_turret.png',
'cannon':'cartoon_heavy_mortar_turret.png',
'burn':'molten_flame_cannon_turret.png',
'freeze':'icy_crystal_freeze_turret.png',
'poison':'neon_toxic_chemical_turret_sprite.png',
'lightning':'golden_tesla_tower_turret.png',
'spike':'armored_orange_spike_trap.png',
'antiair':'isometric_orange_accented_aa_turret.png',
}

def build_base(name):
    path=SRC/(f'tower_{name}_base.png')
    if path.exists(): return Image.open(path).convert('RGBA')
    if name in SOURCE_MAP:
        ref=REF/SOURCE_MAP[name]
        if not ref.exists(): raise FileNotFoundError(f'Reference missing for {name}: {ref}')
        im=clean_source(ref)
    elif name=='gatling': im=gatling_base()
    elif name=='vortex': im=vortex_base()
    elif name=='command': im=command_base()
    else: raise ValueError(name)
    to_png(im,path);return im

def frames_tower(name):
    base=build_base(name)
    idle=[];fire=[];idle_vfx=[];attack_vfx=[]
    for f in range(4):
        iv=blank(); overlay(name,'idle',f,iv,False)
        fv=blank(); overlay(name,'attack',f,fv,True)
        ai=base.copy(); ai.alpha_composite(iv)
        dx=[0,-1,-1,0][f] if name in ('gunner','rapid','cannon','antiair','gatling') else 0
        af=shifted(base,dx,0)
        af.alpha_composite(fv)
        idle.append(ai);fire.append(af);idle_vfx.append(iv);attack_vfx.append(fv)
    return base,idle,fire,idle_vfx,attack_vfx

def sheet_2rows(rows,sz):
    img=blank(sz*4,sz*len(rows))
    for y,row in enumerate(rows):
        for x,frame in enumerate(row):img.alpha_composite(frame,(x*sz,y*sz))
    return img

def gif(frames,path,sz=40,ms=120,loop=True):
    # show enlarged on charcoal backdrop; nearest-neighbor; exact frames as exported PNG
    scale=8 if sz==40 else 3
    pf=[]
    for fr in frames:
        b=Image.new('RGBA',(sz,sz),(23,29,41,255));b.alpha_composite(fr)
        u=b.resize((sz*scale,sz*scale),Image.Resampling.NEAREST)
        pf.append(u.convert('RGB').quantize(colors=100,method=Image.Quantize.MEDIANCUT,dither=Image.Dither.NONE))
    ds=[ms]*len(pf)
    if not loop:ds[-1]=500
    pf[0].save(path,save_all=True,append_images=pf[1:],duration=ds,loop=0 if loop else 1,disposal=2,optimize=False)

def wall_tile(mask):
    # N 1, E 2, S 4, W 8; 40px continuous stone top-down fortification
    N,E,S,W=(bool(mask&j) for j in (1,2,4,8))
    top=blank(); outline=C['black'];stone=C['stone'];shade=C['shadow'];silver=C['silver'];wood=C['wood']
    # draw a union of connected arms so adjacent tiles join *exactly* at boundaries
    m=Image.new('L',(40,40),0);md=ImageDraw.Draw(m)
    md.rectangle((10,10,29,29),fill=255)
    if N: md.rectangle((10,0,29,20),fill=255)
    if E: md.rectangle((20,10,39,29),fill=255)
    if S: md.rectangle((10,20,29,39),fill=255)
    if W: md.rectangle((0,10,20,29),fill=255)
    # outline only external edges; do not outline at tile border on connected ends
    mp=m.load()
    for y in range(40):
        for x in range(40):
            if not mp[x,y]:continue
            edge=any(x+dx<0 or x+dx>=40 or y+dy<0 or y+dy>=40 or (mp[x+dx,y+dy]==0) for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)))
            # check edges that leave tile and are connected: omit interior seam
            if x==0 and W:edge=any((y+dy<0 or y+dy>=40 or mp[x,y+dy]==0) for dy in (-1,1))
            if x==39 and E:edge=any((y+dy<0 or y+dy>=40 or mp[x,y+dy]==0) for dy in (-1,1))
            if y==0 and N:edge=any((x+dx<0 or x+dx>=40 or mp[x+dx,y]==0) for dx in (-1,1))
            if y==39 and S:edge=any((x+dx<0 or x+dx>=40 or mp[x+dx,y]==0) for dx in (-1,1))
            top.putpixel((x,y),outline if edge else stone)
    # subtle top left highlight and side darker face
    for y in range(40):
        for x in range(40):
            if mp[x,y] and top.getpixel((x,y))==stone:
                if (x+y)%13==0 and y%6<2:top.putpixel((x,y),C['metal2'])
                if x>0 and mp[x-1,y]==0:top.putpixel((x,y),silver)
                if y>0 and mp[x,y-1]==0:top.putpixel((x,y),silver)
                if y<39 and mp[x,y+1]==0:top.putpixel((x,y),shade)
    # continuous wood strip only along actual oriented connections; no repeated posts
    if N or S:
        y0=0 if N else 17; y1=39 if S else 22
        rect(top,(19,y0,21,y1),wood)
        rect(top,(19,y0,19,y1),C['orange'])
    if E or W:
        x0=0 if W else 17; x1=39 if E else 22
        rect(top,(x0,19,x1,21),wood)
        rect(top,(x0,19,x1,19),C['orange'])
    degree=sum((N,E,S,W))
    if degree==0:
        rect(top,(15,15,24,24),C['metal2'],outline);rect(top,(18,17,22,20),silver)
    if degree==1:
        # end posts at the exposed facing side
        x,y=(20,31) if N else (20,8) if S else (8,20) if E else (31,20)
        rect(top,(x-4,y-4,x+4,y+4),wood,outline)
        rect(top,(x-3,y-3,x+2,y-2),C['orange'])
    if degree==2 and ((N and E) or (E and S) or (S and W) or (W and N)):
        rect(top,(17,17,23,23),wood,outline);rect(top,(18,18,22,19),C['orange'])
    return top

def make_wall():
    base=wall_tile(0)
    to_png(base,D/'tower_wall.png')
    # 16-connection atlas, 4 columns x 4 rows; mask i maps to (i %4, i//4).
    atlas=blank(160,160)
    for mask in range(16):atlas.alpha_composite(wall_tile(mask),((mask%4)*40,(mask//4)*40))
    to_png(atlas,D/'tower_wall_autotile_16.png')
    # 4 frame static idle + placement/sparkle pseudo-animation
    idle=[base.copy() for _ in range(4)];action=[]
    for i in range(4):
        a=base.copy()
        if i<3:
            sparkle(a,17+i*2,12+i*2,C['cream'] if i==1 else C['gold'],1)
        action.append(a)
    sheet=sheet_2rows([idle,action],40)
    to_png(sheet,D/'tower_wall_sheet.png')
    gif(idle,D/'tower_wall_idle.gif',ms=150)
    gif(action,D/'tower_wall_placement.gif',ms=160)
    data={"name":"wall","class":"wall","frame_size":[40,40],"columns":4,"rows":2,"sheet_size":[160,80],"animations":{"idle":{"row":0,"frames":4,"fps":4,"loop":True},"placement":{"row":1,"frames":4,"fps":6,"loop":False}},"autotile":{"file":"tower_wall_autotile_16.png","columns":4,"rows":4,"bitmask":{"N":1,"E":2,"S":4,"W":8},"tile_index_formula":"index = (N?1:0) | (E?2:0) | (S?4:0) | (W?8:0)","tile_rect_formula":"(index % 4) * 40, (index // 4) * 40, 40, 40"},"asset_note":"Keep autotile under combat tower bases; wall is not a gun."}
    (D/'tower_wall_frames.json').write_text(json.dumps(data,indent=2))
    META.append(data)

def make_vortex_large():
    # 120x120 true 3x3 zone energy well; 4 idle + 4 activate frames. All art
    # fits inside the canvas; central eye anchored at pixel (60,60).
    rows=[]
    for mode in ('idle','activate'):
        frames=[]
        for f in range(4):
            im=blank(120)
            # soft-style *hard-edged* concentric circles, semi-open arcs
            oellipse(im,(12,12,107,107),None,C['purple'],3)
            oellipse(im,(18,18,101,101),None,C['pink'] if mode=='activate' else C['purple'],2)
            oellipse(im,(26,26,93,93),C['black'],C['metal2'],3)
            oellipse(im,(35,35,84,84),C['purple'],C['black'],2)
            oellipse(im,(44,44,75,75),C['black'],C['pink'],2)
            circ(im,60,60,7,C['pink']);circ(im,60,60,3,C['cream'])
            for j in range(8):
                a=math.radians(j*45+f*24)
                x=60+43*math.cos(a);y=60+43*math.sin(a)
                circ(im,int(x),int(y),3 if mode=='activate' else 2,C['pink'] if j%2 else C['purple'])
            for j in range(5):
                a=math.radians(j*72-f*36)
                r=30 if mode=='idle' else 28+f*2
                xx=int(60+r*math.cos(a));yy=int(60+r*math.sin(a))
                sparkle(im,xx,yy,C['cream'],2 if mode=='activate' else 1)
            frames.append(im)
        rows.append(frames)
    sh=sheet_2rows(rows,120)
    to_png(sh,D/'tower_vortex_3x3_sheet.png')
    to_png(rows[0][0],D/'tower_vortex_3x3.png')
    gif(rows[0]+rows[1],D/'tower_vortex_3x3_preview.gif',120,150)
    return {"vortex_3x3":{"frame_width":120,"frame_height":120,"sheet_size":[480,240],"animation_rows":{"idle":0,"activate":1}}}

def make_tower(name):
    base,idle,fire,iv,fx=frames_tower(name)
    sh=sheet_2rows([idle,fire],40)
    fxsh=sheet_2rows([iv,fx],40)
    to_png(base,D/f'tower_{name}.png')
    to_png(sh,D/f'tower_{name}_sheet.png')
    to_png(fxsh,D/f'tower_{name}_vfx_sheet.png')
    gif(idle,D/f'tower_{name}_idle.gif',ms=160)
    gif(fire,D/f'tower_{name}_action.gif',ms=105,loop=True)
    gif(idle[:2]+fire+idle[2:],D/f'tower_{name}_preview.gif',ms=140,loop=True)
    actionname={'gunner':'shoot','rapid':'shoot','cannon':'shoot','burn':'cast','freeze':'cast','poison':'cast','lightning':'cast','spike':'trigger','antiair':'shoot','gatling':'shoot','vortex':'activate','command':'signal'}[name]
    data={"name":name,"class":"tower","frame_size":[40,40],"columns":4,"rows":2,"sheet_size":[160,80],"animations":{"idle":{"row":0,"frame_count":4,"fps":6,"loop":True},actionname:{"row":1,"frame_count":4,"fps":10,"loop":False}},"anchor":{"x":20,"y":20},"vfx_sheet":f'tower_{name}_vfx_sheet.png',"body_sheet":f'tower_{name}_sheet.png',"asset_notes":"Flat gameplay 40px art. Fire action on actual shot/cast, not continuously; keep original projectile system."}
    if name=='vortex': data.update(make_vortex_large())
    (D/f'tower_{name}_frames.json').write_text(json.dumps(data,indent=2))
    META.append(data)

def make_icons():
    icons={'fire':C['orange'],'ice':C['ice'],'poison':C['green'],'lightning':C['gold']}
    for k,color in icons.items():
        a=blank(16)
        if k=='fire':poly(a,[(8,2),(11,8),(13,6),(12,12),(7,15),(4,12),(5,7)],color);poly(a,[(8,7),(10,12),(7,13),(6,10)],C['cream'])
        elif k=='ice':poly(a,[(8,1),(13,7),(8,15),(3,7)],color);line(a,[(8,2),(8,13)],C['cream'])
        elif k=='poison':poly(a,[(8,1),(13,10),(11,14),(5,14),(3,10)],color);circ(a,7,10,2,C['lime'])
        elif k=='lightning':poly(a,[(9,1),(4,8),(8,8),(6,15),(13,6),(9,6)],color)
        to_png(a,D/f'icon_element_{k}.png')
    abilities=['air_strike','supply_drop','barricade_spike','recon_flare']
    for k in abilities:
        a=blank(16)
        if k=='air_strike':poly(a,[(8,1),(11,7),(14,9),(9,11),(8,15),(7,11),(2,9),(5,7)],C['orange']);rect(a,(7,4,9,9),C['cream'])
        elif k=='supply_drop':rect(a,(2,5,13,13),C['wood'],C['black']);line(a,[(7,5),(7,13)],C['gold'],2);rect(a,(6,1,9,4),C['silver'])
        elif k=='barricade_spike':rect(a,(2,10,13,13),C['wood']);[poly(a,[(x-2,11),(x,2),(x+2,11)],C['silver']) for x in (4,8,12)]
        elif k=='recon_flare':line(a,[(8,13),(8,6)],C['metal2'],2);circ(a,8,4,3,C['orange']);sparkle(a,8,4,C['cream'],2)
        to_png(a,D/f'icon_command_{k}.png')

# Compute robust inspection for final RGBA output frames.
def inspect(path,frame_size=40, rows=2):
    im=Image.open(path).convert('RGBA')
    assert im.size==(frame_size*4,frame_size*rows),(path,im.size)
    vals=set();alphas=set();issues=[]
    for p in im.getdata():
        if p[3]:vals.add(p)
        alphas.add(p[3])
    for y in range(rows):
        for x in range(4):
            crop=im.crop((frame_size*x,frame_size*y,frame_size*(x+1),frame_size*(y+1)))
            if crop.getbbox() is None: issues.append(f'blank[{y},{x}]')
    return {"file":path.name,"size":list(im.size),"opaque_colors":len(vals),"binary_alpha":alphas<={0,255},"blank_frames":issues}

def build_all():
    make_wall()
    for n in ['gunner','rapid','cannon','burn','freeze','poison','lightning','spike','antiair','gatling','vortex','command']:
        make_tower(n)
    make_icons()
    (D/'tower_manifest.json').write_text(json.dumps({"version":1,"generated":"2026-10-20","towers":META,"source_reference_note":"Most towers derive from the conversation's approved hi-res artwork. Gatling, Vortex, Command and wall-connect tiles drawn with Pillow."},indent=2))
    stats=[]
    for n in ['wall','gunner','rapid','cannon','burn','freeze','poison','lightning','spike','antiair','gatling','vortex','command']:
        stats.append(inspect(D/f'tower_{n}_sheet.png'))
    stats.append(inspect(D/'tower_vortex_3x3_sheet.png',120,2))
    # verify body raster fits cell and transparency and sheet exactly
    for n in ['wall','gunner','rapid','cannon','burn','freeze','poison','lightning','spike','antiair','gatling','vortex','command']:
        a=Image.open(D/f'tower_{n}.png').convert('RGBA')
        assert a.size==(40,40)
        assert a.getbbox() is not None
    assert Image.open(D/'tower_wall_autotile_16.png').size==(160,160)
    fails=[s for s in stats if not s['binary_alpha'] or s['blank_frames']]
    (ROOT/'VALIDATION.json').write_text(json.dumps({"sheets":stats,"check_failures":fails,"all_pass":not fails},indent=2))
    print('VALIDATION',len(stats),'failed',len(fails))
    for s in stats:print(s['file'],s['size'],s['opaque_colors'])
    (ROOT/'README_CURSOR.md').write_text('''# WaveDefence tower sprite pack – Godot 4\n\nCopy `assets/sprites/towers/` into your Godot project. Every tower has a transparent `tower_NAME.png` 40×40 idle frame; a `tower_NAME_sheet.png` 160×80 (4 columns, 2 rows of 40×40), row 0 idle, row 1 shoot/cast/trigger; plus `tower_NAME_vfx_sheet.png` same layout with isolated effect layers; `tower_NAME_frames.json` and corresponding animated GIF previews.\n\nThe idle and combat effect animations are *prototypes*. Actual firing should be synchronized to the existing projectile/tower attack callbacks, not played endlessly. Keep existing gameplay and stats unchanged. Nearest texture filter recommended in Godot to preserve crisp pixels; center sprites at (20,20).\n\nWall: `tower_wall_autotile_16.png` is a 4×4 atlas of 40px neighbor masks. N=1, E=2, S=4, W=8. Compute mask for each wall cell and choose index `% 4` column and `// 4` row. Recompute on placement/deletion; a combat tower placed atop a wall should not remove that wall's visual connection. The wall itself doesn't shoot; `placement.gif` is cosmetic only.\n\nVortex: `tower_vortex_3x3_sheet.png` is 480×240, with four 120×120 frames per row (idle / activate). Center artwork on the 3×3 block; `tower_vortex.png` remains its 40×40 shop icon. The 3×3 zone should not be interpreted as collision/hitbox art – keep existing build rules.\n\nExtra: elemental 16×16 and Command ability 16×16 icons are included.\n\nTo rebuild the *exact derived animations* from included sources, run `python tools/build_towers.py` after `pip install pillow`. Source images are in `tools/references/` and processed base poses in `tools/base_art/`. The builder does not overwrite existing game code.\n\nQA: `VALIDATION.json` reports actual sheet dimensions, opaque color counts, binary alpha, and nonempty cells. This is graphical asset validation only; Godot runtime integration has not been tested.\n''')
    readme = ROOT/'README_CURSOR.md'
    readme.write_text(readme.read_text() + "\n## Godot helper\n\n`tools/tower_sprite_loader.gd` constructs a `SpriteFrames` resource from each atlas. Move it into your Godot project; use `$AnimatedSprite2D.sprite_frames = WaveTowerSprites.make_frames(\"gunner\")`. On a shot, `$AnimatedSprite2D.play(\"action\")`; on completion, return to `idle`. For 3×3 Vortex, call `make_frames(\"vortex\", true)` on a node centered across the locked 3×3 zone. For the continuous wall, call `WaveTowerSprites.wall_tile(mask)` and set a Sprite2D texture, updating it when neighbors change. Avoid overlaying the VFX atlas on the *already composited* main animation sheet; use VFX with the still base pose if separately layered.\n")
    make_overview()
    return stats

def make_overview():
    names=['wall','gunner','rapid','cannon','burn','freeze','poison','lightning','spike','antiair','gatling','vortex','command']
    cols=5;size=140;tileh=175;pad=12
    canvas=Image.new('RGB',(cols*size+pad*2,3*tileh+pad*2),(26,32,43))
    d=ImageDraw.Draw(canvas)
    for k,n in enumerate(names):
        x=pad+(k%cols)*size; y=pad+(k//cols)*tileh
        d.rounded_rectangle((x+3,y+3,x+size-7,y+tileh-6),radius=9,outline=(57,70,85),width=2)
        im=Image.open(D/f'tower_{n}.png').convert('RGBA').resize((112,112),Image.Resampling.NEAREST)
        canvas.paste(im,(x+11,y+10),im)
        d.text((x+15,y+131),n.upper(),fill=(242,245,249))
    canvas.save(ROOT/'TOWER_OVERVIEW.png')

if __name__=='__main__': build_all()
