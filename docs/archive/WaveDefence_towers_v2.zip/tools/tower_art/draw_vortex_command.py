#!/usr/bin/env python3
"""Code-drawn Vortex and Command towers matching the converted showcase towers.
40x40 frames, 160x80 sheet: row 0 idle (4), row 1 action (4). Usage: python draw_towers.py <out_dir>"""
import math, os, sys
from PIL import Image, ImageDraw
K=8; N=40
OUT=sys.argv[1] if len(sys.argv)>1 else "out"
OUTLINE=(18,16,26)
M0=(32,34,48); M1=(58,62,82); M2=(92,98,122); M3=(138,146,168); M4=(190,198,216)

class C:
    def __init__(s): s.im=Image.new("RGBA",(N*K,N*K),(0,0,0,0)); s.d=ImageDraw.Draw(s.im,"RGBA"); s.pal=set()
    def _c(s,c): s.pal.add(tuple(c[:3])); return (*c[:3],255) if len(c)==3 else c
    def P(s,pts): return [(x*K,y*K) for x,y in pts]
    def ell(s,cx,cy,rx,ry,c):
        if rx>0 and ry>0: s.d.ellipse([(cx-rx)*K,(cy-ry)*K,(cx+rx)*K,(cy+ry)*K],fill=s._c(c))
    def poly(s,pts,c): s.d.polygon(s.P(pts),fill=s._c(c))
    def rect(s,x0,y0,x1,y1,c): s.d.rectangle([x0*K,y0*K,x1*K,y1*K],fill=s._c(c))
    def line(s,pts,w,c): s.d.line(s.P(pts),fill=s._c(c),width=max(1,int(w*K)),joint="curve")
    def arc(s,cx,cy,rx,ry,a0,a1,w,c):
        s.d.arc([(cx-rx)*K,(cy-ry)*K,(cx+rx)*K,(cy+ry)*K],a0,a1,fill=s._c(c),width=max(1,int(w*K)))
    def done(s):
        sm=s.im.resize((N,N),Image.BOX); px=sm.load(); pal=list(s.pal)
        out=Image.new("RGBA",(N,N),(0,0,0,0)); op=out.load()
        for y in range(N):
            for x in range(N):
                r,g,b,a=px[x,y]
                if a<110: continue
                op[x,y]=(*min(pal,key=lambda p:(p[0]-r)**2+(p[1]-g)**2+(p[2]-b)**2),255)
        res=out.copy(); rp=res.load()
        for y in range(N):
            for x in range(N):
                if op[x,y][3]==0:
                    for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                        xx,yy=x+dx,y+dy
                        if 0<=xx<N and 0<=yy<N and op[xx,yy][3]: rp[x,y]=(*OUTLINE,255); break
        return res

def pedestal(c, light, light_hi, lit_level=0.0):
    """Shared gunmetal base in 3/4 view: glowing accent rim + 4 big panel lights."""
    c.ell(20,33.4,13.6,4.2,M0); c.rect(6.4,27.4,33.6,33.4,M1)
    c.rect(6.4,27.6,9.6,33.2,M2); c.rect(30.6,27.6,33.6,33.2,M0)
    gl = light_hi if lit_level>0.5 else light
    for x0,w in ((8.4,4.6),(14.6,4.8),(20.8,4.8),(27.0,4.6)):
        c.rect(x0,28.2,x0+w,32.2,M0); c.rect(x0+0.7,28.8,x0+w-0.7,31.6,gl)
    c.ell(20,27.4,13.6,4.2,light); c.ell(20,27.0,12.6,3.6,M2); c.ell(19,26.6,8,2.0,M3)   # glowing rim + deck
    c.ell(20,27.0,9.0,2.4,M1); c.ell(20,26.8,8.0,1.9,M2)

# ---------------------------------------------------------------- VORTEX
VD=(54,20,100); VM=(118,52,200); VB=(176,92,244); VP=(242,166,255); VW=(255,236,255)
def vortex(rot, power=0.0, shock=None, lit=0.0):
    c=C(); pedestal(c,VM,VB,lit)
    cx,cy=20,14.5; R=7.4+power*1.6
    # back half of tilted ring
    c.arc(cx,cy+1,12.2,3.6,180,360,1.5,VB)
    # emitter prongs
    for bx,tx in ((11.5,13.6),(28.5,26.4)):
        c.line([(bx,26),(tx,19),(tx+(1 if bx<20 else -1)*1.2,15.5)],2.6,M1); c.line([(bx,26),(tx,19)],1.0,VB)
        c.ell(tx+(1 if bx<20 else -1)*1.2,15.5,1.4,1.4,VB)
    c.line([(20,25.5),(20,21.5)],2.6,M1)
    # orb + spiral
    c.ell(cx,cy,R+1.2,R+1.2,VM); c.ell(cx,cy,R,R,VD)
    for k in range(3):
        a0=rot+k*2*math.pi/3; pts=[]
        for i in range(10):
            t=i/9; a=a0+t*2.4; r=1.2+t*(R-1.0); pts.append((cx+math.cos(a)*r,cy+math.sin(a)*r))
        c.line(pts,1.8,VB); c.line(pts[:6],1.0,VP)
    c.ell(cx,cy,2.6+power,2.6+power,VP); c.ell(cx-0.4,cy-0.4,1.4+power*0.6,1.4+power*0.6,VW)
    # front half of ring + orbiting sparkles
    c.arc(cx,cy+1,12.2,3.6,0,180,1.5,VB); c.arc(cx,cy+1,12.2,3.6,20,160,0.7,VP)
    for k in range(2):
        a=rot*1.5+k*math.pi; x,y=cx+math.cos(a)*12.2,cy+1+math.sin(a)*3.6
        c.ell(x,y,1.1,1.1,VW)
    if shock is not None:
        c.arc(cx,cy,shock,shock*0.9,0,360,1.1,VP)
    return c.done()

# ---------------------------------------------------------------- COMMAND
GO=(255,190,40); GH=(255,236,140); GR=(60,200,110); GRH=(170,255,190); GRD=(20,90,60); RED=(240,70,60)
def command(dish, blink, signal=None, lit=0.0, screen_hi=False):
    c=C(); pedestal(c,GO,GH,lit)
    # bunker: top face + front face (3/4)
    AR=(226,118,30); ARH=(255,168,60)
    c.poly([(10.5,16.8),(29.5,16.8),(31.8,20.2),(8.2,20.2)],M3); c.poly([(11.5,17.4),(28.5,17.4),(29.6,19),(10.4,19)],M4)
    c.rect(8.2,20.2,31.8,26.8,M1)
    c.rect(8.2,20.2,11.6,26.8,AR); c.rect(8.2,20.2,9.4,26.8,ARH); c.rect(28.4,20.2,31.8,26.8,AR); c.rect(30.6,20.2,31.8,26.8,(170,80,20))
    c.rect(12.6,21.0,27.4,25.4,GRD); c.rect(13.2,21.5,26.8,24.9,GRH if screen_hi else GR)   # big screen
    c.line([(13.8,23.6),(15.8,22.4),(17.8,24.0),(19.8,22.2),(21.8,23.4),(24,22.4),(26.2,23.2)],0.7,GRD)
    c.ell(24.8,22.3,0.7,0.7,GH if lit>0.5 else GO)
    # antenna + beacon
    c.line([(12.4,17.2),(12.4,7.2)],1.1,M3); c.line([(11.2,10),(13.6,10)],0.8,M2)
    c.ell(12.4,6.4,1.5,1.5,RED if blink else (120,40,40)); 
    if blink: c.ell(12,6,0.6,0.6,(255,200,190))
    # radar mast + rotating dish (dish = -1..1 facing: -1 left, 0 edge-on, 1 right)
    c.rect(22.3,12.5,24.3,17.2,M1); c.ell(23.3,17.0,3.4,1.2,M2)
    rx=max(1.2,abs(dish)*6.2); cx,cy=23.3,10.2
    c.ell(cx,cy,rx+1.0,4.3,GO); c.ell(cx,cy,rx,3.6,M3)
    if abs(dish)>0.3: c.ell(cx+(0.9 if dish>0 else -0.9),cy,rx*0.62,2.4,M2); c.ell(cx+(1.6 if dish>0 else -1.6),cy,0.9,0.9,GO)
    else: c.line([(cx,cy-3.4),(cx,cy+3.4)],1.0,GH)
    if signal is not None:                                                     # signal arcs from the dish
        for k,r in enumerate(signal):
            if r>0: c.arc(cx+1,cy,r,r,300,60,1.2,GH if k==0 else GO); c.arc(cx-1,cy,r,r,120,240,1.2,GH if k==0 else GO)
    return c.done()

def save(name, idle, act):
    os.makedirs(OUT,exist_ok=True); sh=Image.new("RGBA",(160,80),(0,0,0,0))
    for i,f in enumerate(idle): sh.alpha_composite(f,(i*40,0))
    for i,f in enumerate(act): sh.alpha_composite(f,(i*40,40))
    sh.save(os.path.join(OUT,f"tower_{name}_sheet.png"),optimize=True); idle[0].save(os.path.join(OUT,f"tower_{name}.png"),optimize=True)

if __name__=="__main__":
    # idle: 3-arm spiral turns 30 deg/frame -> 4 frames = 120 deg = seamless loop
    save("vortex",[vortex(i*math.pi/6, lit=(i%2)) for i in range(4)],
                  [vortex(0,0.6,lit=1),vortex(math.pi/6,1.0,shock=9.5,lit=1),vortex(math.pi/3,0.6,shock=12.5,lit=1),vortex(math.pi/2,0.2,lit=0)])
    dishes=[1.0,0.0,-1.0,0.0]
    save("command",[command(dishes[i],blink=i<2) for i in range(4)],
                   [command(1.0,True,[3.5,0],1,True),command(1.0,True,[6.5,3.5],1,True),command(1.0,False,[9.5,6.5],1,False),command(1.0,False,[0,9.5],0,False)])
    print("built vortex + command ->",OUT)
