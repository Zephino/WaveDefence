#!/usr/bin/env python3
"""Anti-Air (missile rack) animation built from the converted showcase sprite.
Idle: rack sweeps +-1px (tracking) + blinking targeting light.
Action: recoil + back-blast -> front rocket launches (tube empties) -> exhaust smoke -> reload."""
import sys, os
from PIL import Image, ImageDraw
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import build_towers_v2 as b
SRC = sys.argv[1]; OUT = sys.argv[2]
base = b.clean_source(Image.open(os.path.join(SRC, "missile_cutout.png")).convert("RGBA"))
RACK_Y = 20                                     # rows <= 20 are the rocket rack, below is the base
NOSE_BOX = (19, 2, 27, 9)                       # front (top) rocket's nose cone
TUBE_DARK = (22,20,28); TUBE = (44,40,54); RIM = (104,108,122)
SMK0=(60,56,64); SMK1=(108,102,110); SMK2=(168,164,170); ORG=(255,140,30); YEL=(255,226,90); WHT=(255,255,255); RED=(232,72,30)

def split(img):
    rack = Image.new("RGBA",(40,40),(0,0,0,0)); low = Image.new("RGBA",(40,40),(0,0,0,0))
    rack.paste(img.crop((0,0,40,RACK_Y+1)),(0,0)); low.paste(img.crop((0,RACK_Y+1,40,40)),(0,RACK_Y+1))
    return rack, low
def compose(rack, low, dx=0, dy=0):
    out = Image.new("RGBA",(40,40),(0,0,0,0)); out.alpha_composite(low); out.alpha_composite(rack,(dx,dy)); return out
def nose_pixels(img):
    px = img.load(); pts = []
    x0,y0,x1,y1 = NOSE_BOX
    for y in range(y0,y1+1):
        for x in range(x0,x1+1):
            r,g,bb,a = px[x,y]
            if a and ((r > 170 and g < 140) or (r > 200 and g > 180 and bb > 150)): pts.append((x,y))
    return pts
NOSE = nose_pixels(base)
def empty_tube(img):
    f = img.copy(); px = f.load()
    cx = sum(p[0] for p in NOSE)/len(NOSE); cy = sum(p[1] for p in NOSE)/len(NOSE)
    for x,y in NOSE:
        d = abs(x-cx)+abs(y-cy)
        px[x,y] = (*(TUBE_DARK if d < 1.6 else (TUBE if d < 2.8 else RIM)),255)
    return f
def puff(d, x, y, r, c, a=255): d.ellipse([x-r,y-r,x+r,y+r], fill=(*c,a))
def light(img, on):
    f = img.copy(); d = ImageDraw.Draw(f)
    if on: d.rectangle([22,29,23,30], fill=(*WHT,255)); d.point([(21,29),(24,30),(22,28),(23,31)], fill=(*RED,255))
    return f
def overlay(img, fn):
    layer = Image.new("RGBA",(40,40),(0,0,0,0)); fn(ImageDraw.Draw(layer)); f = img.copy(); f.alpha_composite(layer); return f


from PIL import ImageDraw as _D
ROCKET_POLY = [(19,1),(25,1),(33,9),(33,16),(24,16),(19,8)]       # front rocket: nose + white body
def rocket_mask():
    m = Image.new("L",(40,40),0); _D.Draw(m).polygon(ROCKET_POLY, fill=255)
    a = base.getchannel("A"); mp = m.load(); ap = a.load()
    out = Image.new("L",(40,40),0); op = out.load(); px = base.load()
    for y in range(40):
        for x in range(40):
            if mp[x,y] and ap[x,y]:
                r,g,bb,_ = px[x,y]
                # keep rocket colours only (red/orange nose, white/cream body, light greys)
                if (r>150 and g<150) or (r>170 and g>165 and bb>150) or (r>130 and abs(r-g)<20 and abs(g-bb)<25):
                    op[x,y] = 255
    return out
RM = rocket_mask()
def rocket_layer(dx, dy):
    lay = Image.new("RGBA",(40,40),(0,0,0,0)); rock = Image.new("RGBA",(40,40),(0,0,0,0)); rock.paste(base,(0,0),RM)
    lay.alpha_composite(rock,(dx,dy)); return lay
def tube_empty(img):
    f = img.copy(); px = f.load(); mp = RM.load()
    for y in range(40):
        for x in range(40):
            if mp[x,y]:
                # empty launch tube: dark interior, darker toward the mouth (upper-left)
                px[x,y] = (*(TUBE_DARK if (x+y) < 34 else TUBE),255)
    return f

rack, low = split(base)
idle = [light(compose(rack,low,dx), on) for dx,on in ((0,True),(-1,False),(0,True),(1,False))]

def blast(d, big=True):                         # back-blast out of the rear (lower-right) of the tube
    puff(d,33,15,2.4 if big else 1.6,ORG); puff(d,34.5,17,1.7,YEL); puff(d,35.5,13.5,1.3,SMK1)
emp = tube_empty(base)
# a0: ignition - rack recoils 1px, back-blast, glow at the rocket tail
r0,l0 = split(base); a0 = compose(r0, l0, 1, 1); a0 = overlay(a0, lambda d: blast(d, True))
# a1: rocket leaves the tube (up-left), flame jet between tube and rocket, empty tube visible
a1 = emp.copy()
def jet(d):
    d.line([(29,13),(26,10)], fill=(*ORG,255), width=3); d.line([(28,12),(26,10)], fill=(*YEL,255), width=1)
    puff(d,33.5,15,1.8,SMK1); puff(d,35,17,1.3,SMK2)
a1 = overlay(a1, jet); a1.alpha_composite(rocket_layer(-2,-1))
# a2: rocket gone (handed to the projectile), exhaust smoke at the tube mouth + rear
a2 = overlay(emp, lambda d: (puff(d,21,5,2.3,SMK2), puff(d,18.5,4,1.5,SMK2), puff(d,34,15,1.7,SMK2)))
# a3: reloaded, last wisp of smoke
a3 = overlay(light(base, True), lambda d: puff(d,19,5,1.4,SMK2))
act = [a0, a1, a2, a3]
sheet = Image.new("RGBA",(160,80),(0,0,0,0))
for i,f in enumerate(idle): sheet.alpha_composite(f,(i*40,0))
for i,f in enumerate(act):  sheet.alpha_composite(f,(i*40,40))
os.makedirs(OUT, exist_ok=True)
sheet.save(os.path.join(OUT,"tower_antiair_sheet.png"), optimize=True); idle[0].save(os.path.join(OUT,"tower_antiair.png"), optimize=True)
print("rocket px:", sum(1 for v in RM.get_flattened_data() if v))
