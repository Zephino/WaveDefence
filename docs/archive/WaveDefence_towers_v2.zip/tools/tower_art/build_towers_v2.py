#!/usr/bin/env python3
"""Convert showcase tower cutouts into WaveDefence 160x80 tower sheets.
Row 0 idle (4 frames): emissive glow pulse + travelling twinkle.
Row 1 action (4 frames): recoil + flash (guns) or charge-up glow (casters).
Muzzle flashes / projectiles come from the separate effects set, so they are NOT baked in here."""
import colorsys, sys, os
from PIL import Image, ImageEnhance
SRC = sys.argv[1]; OUT = sys.argv[2]
TOWERS = {  # game id: (showcase cutout, kind, recoil dx per action frame)
    "cannon":  ("cannon",  "gun",    [-2,-1,0,0]),
    "gatling": ("minigun", "gun",    [-1,0,-1,0]),
    "antiair": ("missile", "gun",    [0,0,0,0]),
    "freeze":  ("ice",     "caster", [0,0,0,0]),
    "burn":    ("fire",    "caster", [0,0,0,0]),
    "poison":  ("poison",  "caster", [0,0,0,0]),
}
def clean_source(im, size=34):          # identical recipe to tools/build_towers.py
    im = im.crop(im.getchannel('A').getbbox())
    sc = min(size/im.width, size/im.height); n = (max(1,round(im.width*sc)), max(1,round(im.height*sc)))
    im = im.resize(n, Image.Resampling.LANCZOS)
    rgb = Image.new('RGB', im.size, (95,94,97)); rgb.paste(im, mask=im.getchannel('A'))
    rgb = ImageEnhance.Contrast(rgb).enhance(1.16)
    rgb = rgb.quantize(colors=28, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE).convert('RGB')
    al = im.getchannel('A').point(lambda a: 255 if a >= 106 else 0)
    rgb = rgb.convert('RGBA'); rgb.putalpha(al)
    out = Image.new('RGBA', (40,40), (0,0,0,0)); out.alpha_composite(rgb, ((40-n[0])//2, (40-n[1])//2)); return out
def emissive(base):
    px = base.load(); pts = []
    for y in range(40):
        for x in range(40):
            r,g,b,a = px[x,y]
            if a:
                h,s,v = colorsys.rgb_to_hsv(r/255,g/255,b/255)
                if v > 0.72 and s > 0.42: pts.append((x,y,v))
    return pts
def lift(c, amt): return tuple(int(c[i] + (255-c[i])*amt) for i in range(3))
def frame(base, em, glow, flash=0.0, dx=0, twinkle=None):
    f = base.copy(); px = f.load()
    for x,y,_ in em:
        r,g,b,a = px[x,y]; px[x,y] = (*lift((r,g,b), glow), a)
    if flash:
        for y in range(40):
            for x in range(40):
                r,g,b,a = px[x,y]
                if a: px[x,y] = (*lift((r,g,b), flash), a)
    if twinkle:
        x,y = twinkle
        for dx2,dy2 in ((0,0),(1,0),(-1,0),(0,1),(0,-1)):
            xx,yy = x+dx2,y+dy2
            if 0<=xx<40 and 0<=yy<40 and px[xx,yy][3]: px[xx,yy] = (255,255,255,255) if (dx2,dy2)==(0,0) else (*lift(px[xx,yy][:3],0.55),255)
    if dx:
        g = Image.new('RGBA',(40,40),(0,0,0,0)); g.alpha_composite(f,(dx,0)); f = g
    return f
def build(tid):
    src, kind, recoil = TOWERS[tid]
    base = clean_source(Image.open(os.path.join(SRC, f"{src}_cutout.png")).convert('RGBA'))
    em = emissive(base)
    spots = sorted(em, key=lambda p: -p[2]); picks = []
    for x,y,v in spots:                               # 4 well-separated twinkle spots
        if all(abs(x-a)+abs(y-b) > 7 for a,b in picks): picks.append((x,y))
        if len(picks) == 4: break
    while len(picks) < 4: picks.append(None)
    idle = [frame(base, em, g, twinkle=picks[i]) for i,g in enumerate([0.0, 0.12, 0.22, 0.12])]
    if kind == "gun":
        act = [frame(base, em, g, flash=fl, dx=d) for g,fl,d in zip([0.45,0.3,0.15,0.0],[0.28,0.12,0.0,0.0],recoil)]
    else:
        act = [frame(base, em, g, flash=fl) for g,fl in zip([0.3,0.55,0.35,0.1],[0.0,0.18,0.06,0.0])]
    sheet = Image.new('RGBA',(160,80),(0,0,0,0))
    for i,f in enumerate(idle): sheet.alpha_composite(f,(i*40,0))
    for i,f in enumerate(act):  sheet.alpha_composite(f,(i*40,40))
    os.makedirs(OUT, exist_ok=True)
    sheet.save(os.path.join(OUT, f"tower_{tid}_sheet.png"), optimize=True)
    idle[0].save(os.path.join(OUT, f"tower_{tid}.png"), optimize=True)
    return len(em)
if __name__ == "__main__":
    for t in TOWERS: print(t, "emissive px:", build(t))
